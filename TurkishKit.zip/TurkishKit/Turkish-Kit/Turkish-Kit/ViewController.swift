//  Sarp Gökdağ
//  TurkishKit
/*  Herkese Merhaba , Aşağıda her bir bölüm yıldızlarla ayrılmış bulunmaktadır.
 İncelenecek Bölümler:
 1-)Storyboard Nedir ? Nasıl Kullanılır ? (UIImage , TextField , PlaceHolder vs.)
 2-)ViewController Nedir ?
 3-)XCode Project ve Playground'un Farkı nedir ?
 4-)Assets Kısa Tanımı
 5-)Uygulamamnın Build Edilip simülatörde İncelenmesi
 Belirlenen Süre : 1 Saat 30 Dakika
 Source Code = github.com/sarpgokdag
 
 
 */

import UIKit
import AVFoundation
var player: AVAudioPlayer?

//**************************************************************************************************************************

class ViewController: UIViewController, UITextFieldDelegate {
    
    //Değişkenleri Ayarlayalım
    var maxTaps = 0
    var currentTaps = 0
    
    
    //**************************************************************************************************************************
    
    // Outlets
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var howManyTapsTxt: UITextField!
    @IBOutlet weak var playBtn: UIButton!
    
    @IBOutlet weak var tapBtn: UIButton!
    @IBOutlet weak var tapsLbl: UILabel!
    
    
    //**************************************************************************************************************************
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.howManyTapsTxt.delegate = self;
    }
    
    //**************************************************************************************************************************
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    //**************************************************************************************************************************
    
    @IBAction func onCoinTapped(_ sender: UIButton!) {
        currentTaps += 1
        updateTapsLbl()
        
        if isGameOver() {
            restartGame()
        }
    }
    
    @IBAction func onPlayButtonPressed(_ sender: UIButton!) {
        if howManyTapsTxt.text != nil && howManyTapsTxt.text != "" {
            logoImg.isHidden = true
            howManyTapsTxt.isHidden = true
            playBtn.isHidden = true
            tapBtn.isHidden = false
            tapsLbl.isHidden = false
            
            
            if let possibleInt = Int(howManyTapsTxt.text!) {
                
                maxTaps = possibleInt
                currentTaps = 0
                updateTapsLbl()
            } else {
                let alertController = UIAlertController(title: " HATA !", message: " Yanlış Karakter Girişi Yaptınız , Lütfen Sayısal Bir Karakter Girişi Yapın. ", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: " Tamam, Devam Et ! ", style: UIAlertActionStyle.destructive, handler: {(alert : UIAlertAction!) in
                    alertController.dismiss(animated: true, completion: nil)
                })
                alertController.addAction(alertAction)
                present(alertController, animated: true, completion: nil)
                
                restartGame()
            }
            
        }
    }
    
    //**************************************************************************************************************************
    
    func restartGame() {
        maxTaps = 0
        howManyTapsTxt.text = ""
        
        logoImg.isHidden = false
        howManyTapsTxt.isHidden = false
        playBtn.isHidden = false
        
        tapBtn.isHidden = true
        tapsLbl.isHidden = true
        
    }
    
    func isGameOver() -> Bool {
        return currentTaps >= maxTaps
    }
    
    func updateTapsLbl() {
        tapsLbl.text = "\(currentTaps) Tuz"
    }
    
}

